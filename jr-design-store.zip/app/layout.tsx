import type React from "react"
import type { Metadata } from "next"
import { Poppins } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import "./globals.css"

const poppins = Poppins({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-poppins",
})

export const metadata: Metadata = {
  title: "JR Design Store | Premium Graphic Design & Branding",
  description:
    "International graphic designer specializing in logo design, brand identity, and digital artwork. Where imagination meets perfection.",
  keywords:
    "Graphic Designer, JR Design Store, Logo Design, Branding Expert, Digital Art, Brand Identity, Poster Design",
  metadataBase: new URL("https://jrdesignstore.com"),
  alternates: {
    canonical: "https://jrdesignstore.com",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  openGraph: {
    title: "JR Design Store | Premium Graphic Design",
    description: "Where imagination meets perfection",
    type: "website",
    url: "https://jrdesignstore.com",
    siteName: "JR Design Store",
    images: [
      {
        url: "https://jrdesignstore.com/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "JR Design Store - Premium Graphic Design",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "JR Design Store | Premium Graphic Design",
    description: "International graphic designer specializing in logo design and branding",
    images: ["https://jrdesignstore.com/og-image.jpg"],
  },
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="scroll-smooth">
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              name: "JR Design Store",
              description: "Premium graphic design and branding services",
              url: "https://jrdesignstore.com",
              telephone: "+1-XXX-XXX-XXXX",
              email: "hello@jrdesignstore.com",
              address: {
                "@type": "PostalAddress",
                addressCountry: "International",
              },
              areaServed: "Worldwide",
              priceRange: "$$",
              sameAs: [
                "https://instagram.com/jrdesignstore",
                "https://linkedin.com/company/jrdesignstore",
                "https://behance.net/jrdesignstore",
              ],
              image: "https://jrdesignstore.com/og-image.jpg",
              knowsAbout: ["Logo Design", "Brand Identity", "Poster Design", "Digital Art"],
            }),
          }}
        />
      </head>
      <body className={`${poppins.className} font-sans antialiased bg-background text-foreground`}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
