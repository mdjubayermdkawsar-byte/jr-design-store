import { Star } from "lucide-react"

const testimonials = [
  {
    name: "Sarah Chen",
    company: "TechFlow Inc.",
    country: "Singapore",
    text: "JR transformed our brand vision into reality. The logo and brand identity are absolutely stunning and perfectly capture our company's essence.",
    rating: 5,
  },
  {
    name: "Marco Rossi",
    company: "Luxury Fashion Co.",
    country: "Italy",
    text: "Working with JR was a pleasure. The attention to detail and creative excellence exceeded all our expectations. Highly recommended!",
    rating: 5,
  },
  {
    name: "Amara Okafor",
    company: "EcoGreen Solutions",
    country: "Nigeria",
    text: "The design work was exceptional. JR understood our mission and created visuals that truly resonate with our target audience.",
    rating: 5,
  },
]

export function TestimonialsSection() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">Client Testimonials</h2>
          <div className="w-16 h-1 bg-accent mx-auto mb-6" />
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Hear from international clients about their experience working with JR Design Store.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="p-8 rounded-lg glass hover:glass-dark transition-all duration-300 animate-fade-in-up"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} size={16} className="fill-accent text-accent" />
                ))}
              </div>
              <p className="text-muted-foreground mb-6 leading-relaxed italic">"{testimonial.text}"</p>
              <div>
                <p className="font-semibold">{testimonial.name}</p>
                <p className="text-sm text-muted-foreground">{testimonial.company}</p>
                <p className="text-sm text-accent">{testimonial.country}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
