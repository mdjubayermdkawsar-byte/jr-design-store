"use client"

import { useState } from "react"
import { X } from "lucide-react"

interface PortfolioItem {
  id: number
  title: string
  category: string
  image: string
  description: string
}

const portfolioItems: PortfolioItem[] = [
  {
    id: 1,
    title: "TechFlow Brand Identity",
    category: "Branding",
    image: "/modern-tech-logo.png",
    description:
      "Complete brand identity system for a tech startup including logo, color palette, and typography guidelines.",
  },
  {
    id: 2,
    title: "Luxury Fashion Poster",
    category: "Poster Design",
    image: "/luxury-fashion-poster-design.jpg",
    description: "High-end fashion campaign poster featuring elegant typography and sophisticated imagery.",
  },
  {
    id: 3,
    title: "EcoGreen Logo",
    category: "Logo Design",
    image: "/eco-friendly-green-logo.jpg",
    description: "Minimalist logo design for an environmental sustainability company.",
  },
  {
    id: 4,
    title: "Social Media Campaign",
    category: "Digital Art",
    image: "/social-media-design-graphics.jpg",
    description: "Comprehensive social media creative suite for a lifestyle brand.",
  },
  {
    id: 5,
    title: "Restaurant Branding",
    category: "Branding",
    image: "/restaurant-brand-identity.png",
    description: "Full branding package including logo, menu design, and brand guidelines.",
  },
  {
    id: 6,
    title: "Digital Illustration",
    category: "Digital Art",
    image: "/digital-art-illustration.jpg",
    description: "Custom digital illustration for editorial and commercial use.",
  },
]

export function PortfolioGallery() {
  const [selectedItem, setSelectedItem] = useState<PortfolioItem | null>(null)

  return (
    <section id="portfolio" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">Portfolio</h2>
          <div className="w-16 h-1 bg-accent mx-auto mb-6" />
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Explore a curated selection of recent projects showcasing diverse design disciplines and creative
            excellence.
          </p>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {portfolioItems.map((item, index) => (
            <div
              key={item.id}
              className="group cursor-pointer animate-fade-in-up"
              style={{ animationDelay: `${index * 100}ms` }}
              onClick={() => setSelectedItem(item)}
            >
              <div className="relative h-80 rounded-lg overflow-hidden glass hover:glass-dark transition-all duration-300">
                <img
                  src={item.image || "/placeholder.svg"}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                  <h3 className="text-xl font-bold text-white mb-2">{item.title}</h3>
                  <p className="text-sm text-white/80">{item.category}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox Modal */}
      {selectedItem && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in-up"
          onClick={() => setSelectedItem(null)}
        >
          <div
            className="bg-card rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto glass"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sticky top-0 flex justify-between items-center p-6 border-b border-border bg-card/95 backdrop-blur">
              <h3 className="text-2xl font-bold">{selectedItem.title}</h3>
              <button onClick={() => setSelectedItem(null)} className="p-2 hover:bg-muted rounded-lg transition-colors">
                <X size={24} />
              </button>
            </div>

            <div className="p-6 space-y-6">
              <img
                src={selectedItem.image || "/placeholder.svg"}
                alt={selectedItem.title}
                className="w-full rounded-lg"
              />
              <div>
                <p className="text-sm font-semibold text-accent mb-2">Category</p>
                <p className="text-lg text-muted-foreground">{selectedItem.category}</p>
              </div>
              <div>
                <p className="text-sm font-semibold text-accent mb-2">Description</p>
                <p className="text-lg text-muted-foreground leading-relaxed">{selectedItem.description}</p>
              </div>
              <button
                onClick={() => setSelectedItem(null)}
                className="w-full px-6 py-3 bg-accent text-accent-foreground rounded-lg font-semibold hover:shadow-lg hover:shadow-accent/50 transition-all duration-300"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  )
}
