export function AboutSection() {
  return (
    <section id="about" className="py-20 px-4 sm:px-6 lg:px-8 bg-muted/30">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12 animate-fade-in-up">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">About JR</h2>
          <div className="w-16 h-1 bg-accent mx-auto" />
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Image Placeholder */}
          <div className="relative h-96 rounded-lg overflow-hidden glass animate-slide-in-left">
            <div className="absolute inset-0 bg-gradient-to-br from-accent/20 to-primary/20 flex items-center justify-center">
              <div className="text-center">
                <div className="text-6xl font-bold text-accent/30 mb-4">JR</div>
                <p className="text-muted-foreground">Creative Designer</p>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="space-y-6 animate-slide-in-right">
            <p className="text-lg text-muted-foreground leading-relaxed">
              I'm JR, a passionate graphic designer with over a decade of experience creating stunning visual identities
              for international clients. My work spans across logo design, brand identity systems, poster design, and
              digital artwork.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed">
              I believe that great design is more than aesthetics—it's about solving problems and telling compelling
              stories. Every project I undertake is approached with meticulous attention to detail and a commitment to
              exceeding expectations.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed">
              My international clientele ranges from startups and small businesses to established corporations, all
              seeking design solutions that elevate their brand presence and connect with their audiences.
            </p>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 pt-6">
              <div className="text-center p-4 rounded-lg bg-accent/10">
                <div className="text-3xl font-bold text-accent">500+</div>
                <p className="text-sm text-muted-foreground">Projects</p>
              </div>
              <div className="text-center p-4 rounded-lg bg-accent/10">
                <div className="text-3xl font-bold text-accent">50+</div>
                <p className="text-sm text-muted-foreground">Countries</p>
              </div>
              <div className="text-center p-4 rounded-lg bg-accent/10">
                <div className="text-3xl font-bold text-accent">10+</div>
                <p className="text-sm text-muted-foreground">Years</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
