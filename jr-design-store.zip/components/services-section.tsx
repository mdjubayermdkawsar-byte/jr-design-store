import { Palette, Sparkles, ImageIcon, Zap } from "lucide-react"

const services = [
  {
    icon: Palette,
    title: "Logo Design",
    description: "Custom logo design that captures your brand essence and stands out in the market.",
  },
  {
    icon: Sparkles,
    title: "Brand Identity",
    description: "Complete brand kits including color palettes, typography, and brand guidelines.",
  },
  {
    icon: ImageIcon,
    title: "Poster Design",
    description: "Eye-catching poster designs for events, campaigns, and promotional materials.",
  },
  {
    icon: Zap,
    title: "Social Media Creatives",
    description: "Engaging graphics and illustrations optimized for all social media platforms.",
  },
]

export function ServicesSection() {
  return (
    <section id="services" className="py-20 px-4 sm:px-6 lg:px-8 bg-muted/30">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">Services</h2>
          <div className="w-16 h-1 bg-accent mx-auto mb-6" />
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Comprehensive design solutions tailored to elevate your brand and captivate your audience.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => {
            const Icon = service.icon
            return (
              <div
                key={index}
                className="p-6 rounded-lg glass hover:glass-dark transition-all duration-300 group animate-fade-in-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="w-12 h-12 bg-accent/20 rounded-lg flex items-center justify-center mb-4 group-hover:bg-accent/30 transition-colors">
                  <Icon className="text-accent" size={24} />
                </div>
                <h3 className="text-xl font-bold mb-3">{service.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{service.description}</p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
