import { Calendar, ArrowRight } from "lucide-react"

const blogPosts = [
  {
    id: 1,
    title: "The Art of Minimalist Logo Design",
    excerpt: "Exploring how simplicity and elegance create powerful brand identities that stand the test of time.",
    date: "Oct 20, 2024",
    category: "Design Tips",
  },
  {
    id: 2,
    title: "Color Psychology in Branding",
    excerpt: "Understanding how colors influence perception and emotion in brand design and marketing.",
    date: "Oct 15, 2024",
    category: "Branding",
  },
  {
    id: 3,
    title: "Latest Design Trends 2024",
    excerpt: "A comprehensive look at the most influential design trends shaping the industry this year.",
    date: "Oct 10, 2024",
    category: "Trends",
  },
]

export function BlogSection() {
  return (
    <section id="blog" className="py-20 px-4 sm:px-6 lg:px-8 bg-muted/30">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">Latest Updates</h2>
          <div className="w-16 h-1 bg-accent mx-auto mb-6" />
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Design insights, industry trends, and creative inspiration from the JR Design Store blog.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {blogPosts.map((post, index) => (
            <article
              key={post.id}
              className="p-6 rounded-lg glass hover:glass-dark transition-all duration-300 group animate-fade-in-up cursor-pointer"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex items-center gap-2 text-sm text-accent mb-3">
                <Calendar size={16} />
                <span>{post.date}</span>
              </div>
              <h3 className="text-xl font-bold mb-3 group-hover:text-accent transition-colors">{post.title}</h3>
              <p className="text-muted-foreground mb-4 leading-relaxed">{post.excerpt}</p>
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-accent bg-accent/10 px-3 py-1 rounded-full">
                  {post.category}
                </span>
                <ArrowRight size={16} className="text-accent group-hover:translate-x-1 transition-transform" />
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
