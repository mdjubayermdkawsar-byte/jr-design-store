"use client"

import type React from "react"

import { useState } from "react"
import { Mail, Linkedin, Instagram, Github } from "lucide-react"

export function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  })
  const [submitted, setSubmitted] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Simulate form submission
    setSubmitted(true)
    setTimeout(() => {
      setFormData({ name: "", email: "", subject: "", message: "" })
      setSubmitted(false)
    }, 3000)
  }

  const socialLinks = [
    { icon: Instagram, href: "https://instagram.com", label: "Instagram" },
    { icon: Linkedin, href: "https://linkedin.com", label: "LinkedIn" },
    { icon: Github, href: "https://github.com", label: "GitHub" },
    { icon: Mail, href: "mailto:hello@jrdesignstore.com", label: "Email" },
  ]

  return (
    <section id="contact" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">Let's Work Together</h2>
          <div className="w-16 h-1 bg-accent mx-auto mb-6" />
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Have a project in mind? I'd love to hear about it. Get in touch and let's create something amazing.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div className="animate-slide-in-left">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-semibold mb-2">Name</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 rounded-lg bg-muted border border-border focus:border-accent focus:outline-none transition-colors"
                  placeholder="Your name"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2">Email</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 rounded-lg bg-muted border border-border focus:border-accent focus:outline-none transition-colors"
                  placeholder="your@email.com"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2">Subject</label>
                <input
                  type="text"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 rounded-lg bg-muted border border-border focus:border-accent focus:outline-none transition-colors"
                  placeholder="Project subject"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2">Message</label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={5}
                  className="w-full px-4 py-3 rounded-lg bg-muted border border-border focus:border-accent focus:outline-none transition-colors resize-none"
                  placeholder="Tell me about your project..."
                />
              </div>
              <button
                type="submit"
                className="w-full px-6 py-3 bg-accent text-accent-foreground rounded-lg font-semibold hover:shadow-lg hover:shadow-accent/50 transition-all duration-300"
              >
                {submitted ? "Message Sent!" : "Send Message"}
              </button>
            </form>
          </div>

          {/* Contact Info */}
          <div className="space-y-8 animate-slide-in-right">
            <div>
              <h3 className="text-2xl font-bold mb-4">Get in Touch</h3>
              <p className="text-muted-foreground leading-relaxed mb-6">
                Whether you have a specific project in mind or just want to explore possibilities, I'm here to help.
                Reach out through any of the channels below.
              </p>
            </div>

            <div className="space-y-4">
              <div className="p-4 rounded-lg glass">
                <p className="text-sm text-muted-foreground mb-1">Email</p>
                <a
                  href="mailto:hello@jrdesignstore.com"
                  className="text-lg font-semibold hover:text-accent transition-colors"
                >
                  hello@jrdesignstore.com
                </a>
              </div>
              <div className="p-4 rounded-lg glass">
                <p className="text-sm text-muted-foreground mb-1">Location</p>
                <p className="text-lg font-semibold">International (Remote)</p>
              </div>
            </div>

            {/* Social Links */}
            <div>
              <p className="text-sm font-semibold text-muted-foreground mb-4">Follow Me</p>
              <div className="flex gap-4">
                {socialLinks.map((link) => {
                  const Icon = link.icon
                  return (
                    <a
                      key={link.label}
                      href={link.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-12 h-12 rounded-lg glass hover:glass-dark flex items-center justify-center text-accent hover:text-accent transition-all duration-300 group"
                      aria-label={link.label}
                    >
                      <Icon size={20} className="group-hover:scale-110 transition-transform" />
                    </a>
                  )
                })}
              </div>
            </div>

            {/* Additional Links */}
            <div className="pt-4 border-t border-border">
              <p className="text-sm font-semibold text-muted-foreground mb-3">Also Available On</p>
              <div className="space-y-2">
                <a href="#" className="block text-accent hover:text-accent/80 transition-colors">
                  Behance
                </a>
                <a href="#" className="block text-accent hover:text-accent/80 transition-colors">
                  Dribbble
                </a>
                <a href="#" className="block text-accent hover:text-accent/80 transition-colors">
                  Fiverr
                </a>
                <a href="#" className="block text-accent hover:text-accent/80 transition-colors">
                  Upwork
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
